﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvyFEM
{
    public class LinearElasticMaterial : ElasticBaseMaterial
    {
        public LinearElasticMaterial() : base()
        {

        }
    }
}
